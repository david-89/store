/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.servis;

import app.dao.KrvniPritisakDAO;
import app.domain.KrvniPritisak;
import app.model.KrvniPritisakModel;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class KrvniPritisakServis {
    
    @Autowired
    private KrvniPritisakDAO krvniPritisakDAO;
    
    public void uspisiKrvniPritisak(KrvniPritisakModel krvniPritisakModel) {
        KrvniPritisak krvniPritisak = new KrvniPritisak();
        krvniPritisak.prepakuj(krvniPritisakModel);
        getKrvniPritisakDAO().upisiKrvniPritisak(krvniPritisak);  
    }
    
    public List dajSveRezultate() {
        List<KrvniPritisak> kpLista = krvniPritisakDAO.dajSveRezultate(); 
        List<KrvniPritisakModel> kpmLista = new ArrayList<>();
        
        for (KrvniPritisak kp : kpLista) {
            KrvniPritisakModel kpm = new KrvniPritisakModel();
            kpm.prepakuj(kp);
            kpmLista.add(kpm);
        }    
        
        return kpmLista;
    }

    /**
     * @return the krvniPritisakDAO
     */
    public KrvniPritisakDAO getKrvniPritisakDAO() {
        return krvniPritisakDAO;
    }

    /**
     * @param krvniPritisakDAO the krvniPritisakDAO to set
     */
    public void setKrvniPritisakDAO(KrvniPritisakDAO krvniPritisakDAO) {
        this.krvniPritisakDAO = krvniPritisakDAO;
    }
}
