
import app.dao.KrvniPritisakDAO;
import app.domain.Customer;
import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author David
 */
public class Test {

    public static void main(String[] args) throws SAXException, ParserConfigurationException, IOException, XPathExpressionException, XPathExpressionException, XPathExpressionException, XPathExpressionException, XPathExpressionException {
        Test test = new Test();
        List<Customer> list = test.getCustomerByName("customer");
        for (Customer c : list) {
            System.out.println(c.getFirstname());
            System.out.println(c.getLastname());
            System.out.println(c.getAge());
            System.out.println("***********");
        }
    }

    public void getElementByName(String tagName) throws ParserConfigurationException, XPathExpressionException, SAXException, IOException {
        NodeList listSought = null;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File("C:\\Users\\David\\Desktop\\myFile.xml"));
        NodeList base = doc.getElementsByTagName(tagName);
        Node baseNode = base.item(0);
        System.out.println(baseNode.getNodeName());
        if (base != null && base.getLength() > 0) {
            for (int i = 0; i < base.getLength(); i++) {
                NodeList subList = base.item(i).getChildNodes();
                for (int j = 0; j < subList.getLength(); j++) {
                    System.out.print(subList.item(j).getTextContent() + ", ");
                }
                System.out.println("");
            }
        }

        /*
        XPathFactory xpathFactory = XPathFactory.newInstance();
        XPath xpath = xpathFactory.newXPath();
        XPathExpression expr = xpath.compile("//customers/customer/firstname");
         */
    }

    public List getElements(String tagName) throws ParserConfigurationException, XPathExpressionException, SAXException, IOException {
        List<String> list = new ArrayList();
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File("C:\\Users\\David\\Desktop\\myFile.xml"));
        NodeList base = doc.getElementsByTagName(tagName);
        Node baseNode = base.item(0);
        // System.out.println(baseNode.getNodeName());
        if (base != null && base.getLength() > 0) {
            for (int i = 0; i < base.getLength(); i++) {
                NodeList subList = base.item(i).getChildNodes();
                for (int j = 0; j < subList.getLength(); j++) {
                    list.add(subList.item(j).getTextContent());
                    //System.out.print(subList.item(j).getTextContent() + ", "); 
                }
                //System.out.println("");
            }
        }
        return list;
    }

    public List getCustomerByName(String tagName) throws ParserConfigurationException, XPathExpressionException, SAXException, IOException {
        List<Customer> list = new ArrayList();
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File("C:\\Users\\David\\Desktop\\myFile.xml"));
        NodeList base = doc.getElementsByTagName(tagName);
        Node baseNode = base.item(0);
        //System.out.println(baseNode.getNodeName());
        if (base != null && base.getLength() > 0) {
            for (int i = 0; i < base.getLength(); i++) {
                Customer customer = new Customer();
                NodeList subList = base.item(i).getChildNodes();
                for (int j = 0; j < subList.getLength(); j++) {
                    String rawData = subList.item(j).getTextContent();
                    switch (j) {
                        case 0:
                            customer.setFirstname(rawData);
                            break;
                        case 1:
                            customer.setLastname(rawData);
                            break;
                        case 2:
                            customer.setAge(rawData);
                            break;
                    }
                    //list.add(customer);

                    // System.out.print(subList.item(j).getTextContent() + ", "); 
                }
                list.add(customer);
                // System.out.println("");
            }
        }
        return list;
    }

}
