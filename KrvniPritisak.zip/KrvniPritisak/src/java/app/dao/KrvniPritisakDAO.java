/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.dao;

import app.domain.Customer;
import app.domain.KrvniPritisak;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

@Repository
public class KrvniPritisakDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public void upisiKrvniPritisak(KrvniPritisak krvniPritisak) {
        Session session = getSessionFactory().getCurrentSession();
        Transaction tx = session.beginTransaction();
        session.save(krvniPritisak);
        tx.commit();
    }

    public List dajSveRezultate() {
        Session session = getSessionFactory().getCurrentSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("FROM KrvniPritisak");
        List listaRezultata = query.list();
        tx.commit();

        return listaRezultata;
    }

    public List getCustomerByName(String tagName) throws ParserConfigurationException, XPathExpressionException, SAXException, IOException {
        List<Customer> list = new ArrayList();
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(new File("C:\\Users\\David\\Desktop\\myFile.xml"));
        NodeList base = doc.getElementsByTagName(tagName);
        Node baseNode = base.item(0);
        //System.out.println(baseNode.getNodeName());
        if (base != null && base.getLength() > 0) {
            for (int i = 0; i < base.getLength(); i++) {
                Customer customer = new Customer();
                NodeList subList = base.item(i).getChildNodes();
                for (int j = 0; j < subList.getLength(); j++) {
                    String rawData = subList.item(j).getTextContent();
                    switch (j) {
                        case 0:
                            customer.setFirstname(rawData);
                            break;
                        case 1:
                            customer.setLastname(rawData);
                            break;
                        case 2:
                            customer.setAge(rawData);
                            break;
                    }
                    //list.add(customer);

                    // System.out.print(subList.item(j).getTextContent() + ", "); 
                }
                list.add(customer);
                // System.out.println("");
            }
        }
        return list;
    }


    /**
     * @return the sessionFactory
     */
    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    /**
     * @param sessionFactory the sessionFactory to set
     */
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
