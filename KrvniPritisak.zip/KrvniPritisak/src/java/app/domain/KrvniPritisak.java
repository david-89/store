/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.domain;

import app.model.KrvniPritisakModel;
import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "krvni_pritisak")
public class KrvniPritisak implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @Column(name = "gornji_pritisak")
    private Integer gornjiPritisak;
    
    @Column(name = "donji_pritisak")
    private Integer donjiPritisak;
    
    @Column(name = "puls")
    private Integer puls;
    
    @Column(name = "vreme", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    private Timestamp vreme;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the gornjiPritisak
     */
    public Integer getGornjiPritisak() {
        return gornjiPritisak;
    }

    /**
     * @param gornjiPritisak the gornjiPritisak to set
     */
    public void setGornjiPritisak(Integer gornjiPritisak) {
        this.gornjiPritisak = gornjiPritisak;
    }

    /**
     * @return the donjiPritisak
     */
    public Integer getDonjiPritisak() {
        return donjiPritisak;
    }

    /**
     * @param donjiPritisak the donjiPritisak to set
     */
    public void setDonjiPritisak(Integer donjiPritisak) {
        this.donjiPritisak = donjiPritisak;
    }

    /**
     * @return the puls
     */
    public Integer getPuls() {
        return puls;
    }

    /**
     * @param puls the puls to set
     */
    public void setPuls(Integer puls) {
        this.puls = puls;
    }

    /**
     * @return the vreme
     */
    public Timestamp getVreme() {
        return vreme;
    }

    /**
     * @param vreme the vreme to set
     */
    public void setVreme(Timestamp vreme) {
        this.vreme = vreme;
    }
    
    public void prepakuj(KrvniPritisakModel krvniPritisakModel) {
        this.setDonjiPritisak(krvniPritisakModel.getDonjiPritisak());
        this.setGornjiPritisak(krvniPritisakModel.getGornjiPritisak());
        this.setId(krvniPritisakModel.getId());
        this.setPuls(krvniPritisakModel.getPuls());
        this.setVreme(krvniPritisakModel.getVreme());
    }
    
    
}
