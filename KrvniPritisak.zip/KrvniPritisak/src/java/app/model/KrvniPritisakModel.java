/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.model;

import app.domain.KrvniPritisak;
import java.sql.Timestamp;

/**
 *
 * @author David
 */
public class KrvniPritisakModel {
    private Integer id;
    private Integer gornjiPritisak;
    private Integer donjiPritisak;
    private Integer puls;
    private Timestamp vreme;

    /**
     * @return the id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return the gornjiPritisak
     */
    public Integer getGornjiPritisak() {
        return gornjiPritisak;
    }

    /**
     * @param gornjiPritisak the gornjiPritisak to set
     */
    public void setGornjiPritisak(Integer gornjiPritisak) {
        this.gornjiPritisak = gornjiPritisak;
    }

    /**
     * @return the donjiPritisak
     */
    public Integer getDonjiPritisak() {
        return donjiPritisak;
    }

    /**
     * @param donjiPritisak the donjiPritisak to set
     */
    public void setDonjiPritisak(Integer donjiPritisak) {
        this.donjiPritisak = donjiPritisak;
    }

    /**
     * @return the puls
     */
    public Integer getPuls() {
        return puls;
    }

    /**
     * @param puls the puls to set
     */
    public void setPuls(Integer puls) {
        this.puls = puls;
    }

    /**
     * @return the vreme
     */
    public Timestamp getVreme() {
        return vreme;
    }

    /**
     * @param vreme the vreme to set
     */
    public void setVreme(Timestamp vreme) {
        this.vreme = vreme;
    }
    
    public void prepakuj(KrvniPritisak krvniPritisak) {
        this.setId(krvniPritisak.getId());
        this.setGornjiPritisak(krvniPritisak.getGornjiPritisak());
        this.setDonjiPritisak(krvniPritisak.getDonjiPritisak());
        this.setPuls(krvniPritisak.getPuls());
        this.setVreme(krvniPritisak.getVreme()); 
    }
    
}
