/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package screenshottaker2;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ScreenShotTaker2 extends JFrame {

    public static String putanja;
    public static JLabel jLabel1 = new JLabel();
    public static JLabel jLabel2 = new JLabel();
    public static JTextField jTextField = new JTextField();
    public static JButton jButton1 = new JButton();
    public static JButton jButton2 = new JButton();
    public static JButton jButton3 = new JButton();
    public static JPanel jPanelUp = new JPanel();
    public static JPanel jPanelCenter = new JPanel();
    public static JPanel jPanelCenterInner = new JPanel();
    public static JPanel jPanelDown = new JPanel();

    public static void main(String[] args) {                                    //main method to start the window
        JFrame jFrame = new JFrame();
        jFrame.setSize(400, 250);
        jFrame.setDefaultCloseOperation(jFrame.EXIT_ON_CLOSE);
        jFrame.setLocationRelativeTo(null);

        jPanelUp.add(jLabel1);                                                  //adds the first label
        jPanelCenterInner.add(jLabel2);                                         //adds the enter interval label and textfield
        jPanelCenterInner.add(jTextField);
        jPanelCenter.add(jPanelCenterInner);

        jPanelDown.setPreferredSize(new Dimension(80, 60));                      //adds and adjusts buttons
        jPanelDown.add(jButton1);
        jPanelDown.add(jButton2);
        jPanelDown.add(jButton3);
        jButton1.setText("Start");
        jButton2.setText("Stop");
        jButton3.setText("Choose file");

        GridLayout grid = new GridLayout(2, 2, 5, 5);
        jPanelCenterInner.setLayout(grid);                                      //sets gridLayout of central panel

        jFrame.add(jPanelUp, BorderLayout.PAGE_START);
        jFrame.add(jPanelCenter, BorderLayout.CENTER);
        jFrame.add(jPanelDown, BorderLayout.PAGE_END);

        jLabel1.setText("Screenshot taker");                                    //defines texts in Labels
        jLabel2.setText("Enter the interval: ");

        MyMouseAdapter myAdapter = new MyMouseAdapter();                        //adds listeners to buttons
        MyMouseAdapter2 myAdapter2 = new MyMouseAdapter2();
        jButton1.addMouseListener(myAdapter);
        jButton2.addMouseListener(myAdapter2);
        jButton3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int returnValue = fileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    putanja = selectedFile.getAbsolutePath();
                    System.out.println(selectedFile.getName());
                }
            }
        });

        jFrame.setVisible(true);
    }

    // end of main method
    public static class MyMouseAdapter extends MouseAdapter {                          //starts the listener

        Random r = new Random();

        @Override
        public void mouseClicked(MouseEvent e) {

            startShooting();
        }

        public void startShooting() {

            Thread thread = new Thread(() -> {

                int interval = 0;

                String intervalString = jTextField.getText();

                try {
                    interval = Integer.parseInt(intervalString);

                    DateFormat dateFormat = new SimpleDateFormat("HH.mm");
                    Date date = new Date();
                    String vremeHvatanja = dateFormat.format(date);

                    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                    Rectangle screenRect = new Rectangle(screenSize);
                    try {
                        Robot robot = new Robot();
                        BufferedImage image = robot.createScreenCapture(screenRect);
                        ImageIO.write(image, "jpg", new File(putanja + "\\slika" + vremeHvatanja + ".jpg"));
                    } catch (AWTException ex) {
                        System.out.println("Greska u robotu!");
                    } catch (IOException ex) {
                        System.out.println("Greska pri hvatanju slike!");
                    }

                    System.out.println("Slika uhvacena!");

                    try {
                        Thread.sleep(interval * 60000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(MyMouseAdapter.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    startShooting();

                } catch (Exception ex) {
                    jTextField.setText("Moras uneti ceo broj!");
                    //adjust, do not put a default interval
                }

            });

            thread.start();

        }

    }

    public static class MyMouseAdapter2 extends MouseAdapter {

        public void mouseClicked(MouseEvent e) {

            System.exit(0);
            System.out.println("Program je ugasen!");
        }

    }

}
