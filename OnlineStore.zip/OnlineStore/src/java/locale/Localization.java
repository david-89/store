
package locale;

import java.util.HashMap;
import java.util.Map;


public class Localization {
    private Map<String, Map<String, String>> resourceMap;
    
    public Localization() {
        resourceMap = new HashMap<>();
        HashMap<String, String> englishResources = new HashMap<>();
        englishResources.put("Search", "Search");
        englishResources.put("Login as an Admin", "Login as an Admin");
        englishResources.put("Buy on Online Store - Register as a buyer", "Buy on Online Store - Register as a buyer");
        englishResources.put("Name", "Name");
        englishResources.put("Address", "Address");
        englishResources.put("Email", "Email");
        englishResources.put("CC Balance(&euro;)", "CC Balance(&euro;)");
        englishResources.put("Username", "Username");
        englishResources.put("Password", "Password");
        englishResources.put("Register as a buyer", "Register as a buyer");
        englishResources.put("Register", "Register");
        englishResources.put("Go to online store homepage", "Go to online store homepage");
        
        HashMap<String, String> serbianResources = new HashMap<>();
        serbianResources.put("Search", "Pretraga");
        serbianResources.put("Login as an Admin", "Uloguj se kao admin");
        serbianResources.put("Buy on Online Store - Register as a buyer", "Kupuj u prodavnici - registruj nalog");
        serbianResources.put("Name", "Ime i prezime");
        serbianResources.put("Address", "Adresa");
        serbianResources.put("Email", "Imejl");
        serbianResources.put("CC Balance(&euro;)", "Stanje na kreditnoj kartici(&euro;)");
        serbianResources.put("Username", "Korisnicko ime");
        serbianResources.put("Password", "Lozinka");
        serbianResources.put("Register as a buyer", "Registruj se kao kupac");
        serbianResources.put("Register", "Registruj se");
        serbianResources.put("Go to online store homepage", "Idi na glavnu stranu prodavnice");
        
        HashMap<String, String> frenchResources = new HashMap<>();
        frenchResources.put("Search", "Rechercher");
        frenchResources.put("Login as an Admin", "Identifiez-vous en tant qu'admin");
        frenchResources.put("Buy on Online Store - Register as a buyer", "Enregistrement du compte acheteur");
        frenchResources.put("Name", "Nom");
        frenchResources.put("Address", "Adresse");
        frenchResources.put("Email", "Email");
        frenchResources.put("CC Balance(&euro;)", "Carte de credit(&euro;)");
        frenchResources.put("Username", "Nom d'utilisateur");
        frenchResources.put("Password", "Mot de passe");
        frenchResources.put("Register as a buyer", "Enregistrer un compte acheteur");
        frenchResources.put("Register", "Enregistrer");
        frenchResources.put("Go to online store homepage", "Allez sur la page d'accueil");
        
        resourceMap.put("en", englishResources);
        resourceMap.put("sr", serbianResources);
        resourceMap.put("fr", frenchResources);
    }
    
    public Map<String, String> getLocale(String language) {
        return this.resourceMap.get(language);
    }
}
