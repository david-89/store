/*
    Takes the image file name from the form and 
    saves into DB, then writes the images as bytes 
    to the folder called gallery

*/
package app.images;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.UIDFolder;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet(name = "UploadImages", urlPatterns = {"/UploadImages"})
@MultipartConfig
public class UploadImages extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        Part part1 = request.getPart("image1");
        String filename1 = part1.getHeaders("content-disposition").toString().split("filename=\"")[1].replace("\"]", "");
        //String galleryPath = "C:\\Users\\David\\Desktop\\zavrsni rad\\verzija 46 - konacna pdf\\OnlineStore\\web\\gallery";
        String galleryPath = "C:\\Users\\DAVID\\Desktop\\zavrsni rad\\verzija 49 - konacna\\OnlineStore\\web\\gallery";
        //C:\Users\DAVID\Desktop\zavrsni rad\verzija 49 - konacna\OnlineStore\web\gallery
        String fileNameRead1 = UUID.randomUUID() + part1.getSubmittedFileName();
        String imagePath1 = "gallery" + "/" + fileNameRead1;
        System.out.println("For sql : " + imagePath1);
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_online_store", "root", "dag2003#89");
        String sql = "UPDATE product SET image1=? ORDER BY productId DESC LIMIT 1";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, imagePath1);
        ps.executeUpdate();

        con.close();

        InputStream is1 = part1.getInputStream();
        FileOutputStream fos1 = new FileOutputStream(galleryPath + "/" + fileNameRead1);
        int bt;
        while ((bt = is1.read()) != -1) {
            fos1.write(bt);
        }
        fos1.close();
        is1.close();

        response.sendRedirect("homePageAdmin");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UploadImages.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(UploadImages.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(UploadImages.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(UploadImages.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
