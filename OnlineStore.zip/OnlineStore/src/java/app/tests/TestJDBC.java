
package app.tests;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TestJDBC {
    
    public static void main(String[] args) throws SQLException {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_online_store", "root", "dag2003#89");
        String sql = "UPDATE product SET  image2='test_image2', image3='test_image3' ORDER BY productId DESC LIMIT 1";
        Statement st = con.createStatement();
        st.execute(sql);
        con.close();
    }
}
