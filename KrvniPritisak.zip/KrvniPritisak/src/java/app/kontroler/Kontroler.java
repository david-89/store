/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app.kontroler;

import app.dao.KrvniPritisakDAO;
import app.domain.Customer;
import app.domain.KrvniPritisak;
import app.model.CustomerModel;
import org.springframework.ui.Model;
import app.model.KrvniPritisakModel;
import app.servis.KrvniPritisakServis;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.xml.sax.SAXException;

@Controller
public class Kontroler {

    @Autowired
    private KrvniPritisakServis krvniPritisakServis;

    @Autowired
    private KrvniPritisakDAO krvniPritisakDAO;

    @RequestMapping(value = {"/krvniPritisak", "/"})
    public String beleziPritisak(Model model) {
        model.addAttribute("krvniPritisakModel", new KrvniPritisakModel());
        return "beleziPritisak";
    }

    @RequestMapping(value = "upisiPritisak", method = RequestMethod.POST)
    public String postUpisiPritisak(@ModelAttribute("krvniPritisakModel") KrvniPritisakModel krvniPritisakModel) {
        getKrvniPritisakServis().uspisiKrvniPritisak(krvniPritisakModel);
        return "uspesnoUpisan";
    }

    @RequestMapping(value = "prikaziRezultate")
    public String getRezultati(Model model) {
        List<KrvniPritisakModel> kpmLista = getKrvniPritisakServis().dajSveRezultate();
        model.addAttribute("kpmLista", kpmLista);

        return "rezultati";
    }
    
    @RequestMapping(value = "displayCustomers")
    public String getCustomers(Model model) throws SAXException, ParserConfigurationException, IOException, XPathExpressionException {
        List<Customer> list = getKrvniPritisakDAO().getCustomerByName("customer"); 
        model.addAttribute("customerList", list);
        return "displayCustomers";
    }
    
    @RequestMapping(value = "displayCustomers", method = RequestMethod.POST)
    public String postCustomers(Model model) throws SAXException, ParserConfigurationException, IOException, XPathExpressionException {
        List<Customer> list = getKrvniPritisakDAO().getCustomerByName("customer"); 
        model.addAttribute("customerList", list);
        return "displayCustomers";
    }
    
    

    /**
     * @return the krvniPritisakServis
     */
    public KrvniPritisakServis getKrvniPritisakServis() {
        return krvniPritisakServis;
    }

    /**
     * @param krvniPritisakServis the krvniPritisakServis to set
     */
    public void setKrvniPritisakServis(KrvniPritisakServis krvniPritisakServis) {
        this.krvniPritisakServis = krvniPritisakServis;
    }

    /**
     * @return the krvniPritisakDAO
     */
    public KrvniPritisakDAO getKrvniPritisakDAO() {
        return krvniPritisakDAO;
    }

    /**
     * @param krvniPritisakDAO the krvniPritisakDAO to set
     */
    public void setKrvniPritisakDAO(KrvniPritisakDAO krvniPritisakDAO) {
        this.krvniPritisakDAO = krvniPritisakDAO;
    }

}
